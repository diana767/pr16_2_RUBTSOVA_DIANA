﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace практика16_задание4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Class1> countries = new List<Class1>();

        private void Form1_Load(object sender, EventArgs e)
        {
            if (File.Exists("f.txt"))
            {
                string[] ffile = File.ReadAllLines("f.txt");
                foreach (string ff in ffile)
                {
                    char d = ff.First(c => char.IsDigit(c));
                    string[] part = ff.Split(d);
                    string name = part[0];
                    string popul = d + part[1];
                    int population = int.Parse(popul.Replace(" ", ""));
                    countries.Add(new Class1(name, population));
                }

                var sort = countries.OrderBy(c => c.Name.Length);

                listBox1.Items.Clear();
                foreach (Class1 c in sort)
                {
                    listBox1.Items.Add(c.Name + " " + c.Population);
                }
            }
            else MessageBox.Show("Файл с данными не найден!");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text.Replace(" ", ""), out int rez))
            {
                long n = long.Parse(textBox1.Text.Replace(" ", ""));
                var sortt = countries.Where(c => c.Population > n)
                                       .OrderBy(c => c.Name.Length)
                                       .ToList();
                listBox2.Items.Clear();
                foreach (Class1 c in sortt)
                {
                    listBox2.Items.Add(c.Name + " " + c.Population);
                }
            }
            else MessageBox.Show("Неправильный формат ввода!");
        }

    } 
}
